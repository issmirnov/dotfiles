eval "$(npm completion 2>/dev/null)"
